n = int ( input (' ระบุคะแนนของคุณ' ) )
if(n <50):
  print('F Class')
elif(n<60):
  print('D Class')
elif(n<70):
  print('C Class')
elif(n<80):
  print('B Class')
else:
  print('A Class')
